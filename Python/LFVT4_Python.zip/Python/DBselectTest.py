import sqlite3

connection = sqlite3.connect("northwind.db")

cursor = connection.cursor()

country = {'Germany'}
sqlStatement = "select CustomerID, CompanyName, Address, City " \
               "from Customers " \
               "where Country = ?"

cursor.execute(sqlStatement, country) #schickt Selectstatement an DB

for dataset in cursor:
    print("Kunden-Nr.:", dataset[0])
    print("Kunde:", dataset[1])
    print("Straße", dataset[2])
    print("Stadt", dataset[3])


connection.close()



