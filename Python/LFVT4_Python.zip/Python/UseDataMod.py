
import DataModul
"""
sqlStatement1 = "select FirstName, LastName, Country from Employees " \
               "where country = ?"
sqlStatement2 = "select * from Customers"
params = ("UK", )
dataset = DataModul.getDataList(sqlStatement1, params)
for row in dataset:
    print(row)
"""
params = ('gerfu', 'Gernots Fudies', 'Gernot Grünewald')
sqlinsert = "insert into Customers (CustomerID, CompanyName, ContactName) " \
            "values (?,?,?)"
result = DataModul.getDataList(sqlinsert, params)

print(result)
